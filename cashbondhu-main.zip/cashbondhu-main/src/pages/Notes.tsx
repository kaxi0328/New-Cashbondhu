import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Trash2 } from "lucide-react";
import BackButton from "@/components/BackButton";

const Notes = () => {
  const queryClient = useQueryClient();

  const { data: notes = [], isLoading } = useQuery({
    queryKey: ["notes"],
    queryFn: async () => {
      const { data } = await supabase.from("notes").select("*").order("created_at", { ascending: false });
      return data || [];
    },
  });

  const deleteNote = async (id: string) => {
    await supabase.from("notes").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["notes"] });
  };

  return (
    <div className="pb-24 min-h-screen gradient-hero relative">
      <BackButton to="/dashboard" />
      <div className="max-w-lg mx-auto px-4 pt-6">
        <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-2xl font-bold text-foreground mb-6">
          নোট
        </motion.h1>

        {isLoading ? (
          <p className="text-sm text-muted-foreground text-center py-8">লোড হচ্ছে...</p>
        ) : notes.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">কোনো নোট নেই। নিচের + বাটনে ক্লিক করে নোট যোগ করুন।</p>
        ) : (
          <div className="columns-2 gap-3 space-y-3">
            {notes.map((note: any, i: number) => (
              <motion.div
                key={note.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                whileTap={{ scale: 0.97 }}
                className={`break-inside-avoid ${note.color} rounded-2xl p-4 shadow-card relative group`}
              >
                <button onClick={() => deleteNote(note.id)} className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1 rounded-full hover:bg-destructive/10 transition-all">
                  <Trash2 size={14} className="text-destructive" />
                </button>
                <h3 className="text-sm font-semibold text-foreground mb-2">{note.title}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{note.content}</p>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Notes;
