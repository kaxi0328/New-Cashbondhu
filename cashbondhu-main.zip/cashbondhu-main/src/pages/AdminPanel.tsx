import { useEffect, useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Users, Shield, Check, X, Clock, Search, Download, Filter, ChevronDown, ChevronUp, Eye, Calendar, CreditCard, Moon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import AdminUserCard from "@/components/admin/AdminUserCard";
import AdminPaymentCard from "@/components/admin/AdminPaymentCard";
import AdminUserDetail from "@/components/admin/AdminUserDetail";

export interface UserProfile {
  user_id: string;
  full_name: string | null;
  created_at: string;
  role?: string;
  subscription_status?: string;
  subscription_started?: string;
  subscription_expires?: string;
  islamic_mode?: boolean;
  transaction_count?: number;
  total_income?: number;
  total_expense?: number;
}

export interface PaymentRequest {
  id: string;
  user_id: string;
  method: string;
  phone_number: string;
  transaction_id: string;
  amount: number;
  status: string;
  created_at: string;
  user_name?: string;
}

const AdminPanel = () => {
  const { isAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [payments, setPayments] = useState<PaymentRequest[]>([]);
  const [fetching, setFetching] = useState(true);
  const [tab, setTab] = useState<"users" | "payments">("users");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [paymentFilter, setPaymentFilter] = useState<string>("all");
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [selectedUserTransactions, setSelectedUserTransactions] = useState<any[]>([]);

  useEffect(() => {
    if (!loading && !isAdmin) navigate("/dashboard");
  }, [loading, isAdmin, navigate]);

  useEffect(() => {
    if (!isAdmin) return;
    const fetchData = async () => {
      const { data: profiles } = await supabase.from("profiles").select("*");
      const { data: roles } = await supabase.from("user_roles").select("*");
      const { data: subs } = await supabase.from("subscriptions").select("*");
      const { data: allTransactions } = await supabase.from("transactions").select("user_id, amount, type");

      if (profiles) {
        const mapped = profiles.map((p: any) => {
          const sub = (subs || []).find((s: any) => s.user_id === p.user_id);
          const userTx = (allTransactions || []).filter((t: any) => t.user_id === p.user_id);
          return {
            user_id: p.user_id,
            full_name: p.full_name,
            created_at: p.created_at,
            islamic_mode: p.islamic_mode ?? false,
            role: (roles || []).find((r: any) => r.user_id === p.user_id)?.role || "user",
            subscription_status: sub?.status || "none",
            subscription_started: sub?.started_at,
            subscription_expires: sub?.expires_at,
            transaction_count: userTx.length,
            total_income: userTx.filter((t: any) => t.type === "income").reduce((s: number, t: any) => s + Number(t.amount), 0),
            total_expense: userTx.filter((t: any) => t.type === "expense").reduce((s: number, t: any) => s + Math.abs(Number(t.amount)), 0),
          };
        });
        setUsers(mapped);
      }

      const { data: paymentData } = await supabase.from("payment_requests").select("*").order("created_at", { ascending: false });
      if (paymentData && profiles) {
        const mapped = paymentData.map((pr: any) => ({
          ...pr,
          user_name: (profiles as any[]).find((p) => p.user_id === pr.user_id)?.full_name || "নামহীন",
        }));
        setPayments(mapped);
      }
      setFetching(false);
    };
    fetchData();
  }, [isAdmin]);

  const activateUser = async (userId: string) => {
    const now = new Date();
    const expires = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    const { data: existing } = await supabase.from("subscriptions").select("id").eq("user_id", userId).limit(1);
    if (existing && existing.length > 0) {
      await supabase.from("subscriptions").update({ status: "active", started_at: now.toISOString(), expires_at: expires.toISOString() }).eq("user_id", userId);
    } else {
      await supabase.from("subscriptions").insert({ user_id: userId, status: "active", started_at: now.toISOString(), expires_at: expires.toISOString() });
    }
    setUsers((prev) => prev.map((u) => u.user_id === userId ? { ...u, subscription_status: "active", subscription_started: now.toISOString(), subscription_expires: expires.toISOString() } : u));
    toast({ title: "একটিভ!", description: "সাবস্ক্রিপশন ১ মাসের জন্য একটিভ করা হয়েছে।" });
  };

  const deactivateUser = async (userId: string) => {
    await supabase.from("subscriptions").update({ status: "expired", expires_at: new Date().toISOString() }).eq("user_id", userId);
    setUsers((prev) => prev.map((u) => u.user_id === userId ? { ...u, subscription_status: "expired" } : u));
    toast({ title: "ডিএকটিভ", description: "সাবস্ক্রিপশন বন্ধ করা হয়েছে।" });
  };

  const deleteUser = async (userId: string) => {
    // Delete all user data from all tables
    await Promise.all([
      supabase.from("transactions").delete().eq("user_id", userId),
      supabase.from("accounts").delete().eq("user_id", userId),
      supabase.from("budgets").delete().eq("user_id", userId),
      supabase.from("goals").delete().eq("user_id", userId),
      supabase.from("notes").delete().eq("user_id", userId),
      supabase.from("payment_requests").delete().eq("user_id", userId),
      supabase.from("subscriptions").delete().eq("user_id", userId),
      supabase.from("user_roles").delete().eq("user_id", userId),
    ]);
    await supabase.from("profiles").delete().eq("user_id", userId);
    setUsers((prev) => prev.filter((u) => u.user_id !== userId));
    setPayments((prev) => prev.filter((p) => p.user_id !== userId));
    if (selectedUser?.user_id === userId) setSelectedUser(null);
    toast({ title: "ডিলিট!", description: "ইউজারের সমস্ত ডেটা মুছে ফেলা হয়েছে।" });
  };

  const deleteUserTransactions = async (userId: string) => {
    await supabase.from("transactions").delete().eq("user_id", userId);
    setUsers((prev) => prev.map((u) => u.user_id === userId ? { ...u, transaction_count: 0, total_income: 0, total_expense: 0 } : u));
    setSelectedUserTransactions([]);
    toast({ title: "মুছে ফেলা হয়েছে!", description: "ইউজারের সমস্ত লেনদেন ইতিহাস মুছে ফেলা হয়েছে।" });
  };

  const editUserBalance = async (userId: string, type: "income" | "expense", amount: number, title: string) => {
    const { error } = await supabase.from("transactions").insert({
      user_id: userId,
      type,
      amount: type === "expense" ? -Math.abs(amount) : Math.abs(amount),
      title,
      category: "অ্যাডমিন সমন্বয়",
    });
    if (error) {
      toast({ title: "ত্রুটি!", description: "ব্যালেন্স আপডেট করা যায়নি।", variant: "destructive" });
      return;
    }
    // Refresh user data
    const { data: userTx } = await supabase.from("transactions").select("amount, type").eq("user_id", userId);
    if (userTx) {
      const totalIncome = userTx.filter((t) => t.type === "income").reduce((s, t) => s + Number(t.amount), 0);
      const totalExpense = userTx.filter((t) => t.type === "expense").reduce((s, t) => s + Math.abs(Number(t.amount)), 0);
      setUsers((prev) => prev.map((u) => u.user_id === userId ? { ...u, transaction_count: userTx.length, total_income: totalIncome, total_expense: totalExpense } : u));
    }
    toast({ title: "সফল!", description: "ব্যালেন্স আপডেট করা হয়েছে।" });
  };

  const approvePayment = async (payment: PaymentRequest) => {
    await supabase.from("payment_requests").update({ status: "approved" }).eq("id", payment.id);
    await activateUser(payment.user_id);
    setPayments((prev) => prev.map((p) => p.id === payment.id ? { ...p, status: "approved" } : p));
  };

  const rejectPayment = async (paymentId: string) => {
    await supabase.from("payment_requests").update({ status: "rejected" }).eq("id", paymentId);
    setPayments((prev) => prev.map((p) => p.id === paymentId ? { ...p, status: "rejected" } : p));
    toast({ title: "বাতিল", description: "পেমেন্ট রিকোয়েস্ট বাতিল করা হয়েছে।" });
  };

  const viewUserDetails = async (user: UserProfile) => {
    setSelectedUser(user);
    const { data } = await supabase.from("transactions").select("*").eq("user_id", user.user_id).order("created_at", { ascending: false }).limit(50);
    setSelectedUserTransactions(data || []);
  };

  // Filters
  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      const matchesSearch = !searchQuery || (u.full_name || "").toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === "all" || u.subscription_status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [users, searchQuery, statusFilter]);

  const filteredPayments = useMemo(() => {
    return payments.filter((p) => {
      const matchesSearch = !searchQuery || (p.user_name || "").toLowerCase().includes(searchQuery.toLowerCase()) || p.transaction_id.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesFilter = paymentFilter === "all" || p.status === paymentFilter;
      return matchesSearch && matchesFilter;
    });
  }, [payments, searchQuery, paymentFilter]);

  // Export
  const exportCSV = () => {
    if (tab === "users") {
      const header = "নাম,স্ট্যাটাস,যোগদান,মেয়াদ শেষ,মোট আয়,মোট ব্যয়,লেনদেন,ইসলামিক\n";
      const rows = filteredUsers.map((u) =>
        `"${u.full_name || 'নামহীন'}",${u.subscription_status},${u.created_at},${u.subscription_expires || ''},${u.total_income},${u.total_expense},${u.transaction_count},${u.islamic_mode}`
      ).join("\n");
      downloadCSV(header + rows, "users.csv");
    } else {
      const header = "নাম,মাধ্যম,নম্বর,TxN ID,পরিমাণ,স্ট্যাটাস,তারিখ\n";
      const rows = filteredPayments.map((p) =>
        `"${p.user_name}",${p.method},${p.phone_number},${p.transaction_id},${p.amount},${p.status},${p.created_at}`
      ).join("\n");
      downloadCSV(header + rows, "payments.csv");
    }
    toast({ title: "এক্সপোর্ট সফল!", description: "CSV ফাইল ডাউনলোড হচ্ছে।" });
  };

  const downloadCSV = (content: string, filename: string) => {
    const blob = new Blob(["\uFEFF" + content], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.click();
  };

  const pendingPayments = payments.filter((p) => p.status === "pending");
  const activeUsers = users.filter((u) => u.subscription_status === "active");
  const trialUsers = users.filter((u) => u.subscription_status === "trial");
  const totalRevenue = payments.filter((p) => p.status === "approved").reduce((s, p) => s + p.amount, 0);

  if (loading || fetching) {
    return <div className="min-h-screen gradient-hero flex items-center justify-center"><p className="text-muted-foreground">লোড হচ্ছে...</p></div>;
  }

  if (selectedUser) {
    return (
      <AdminUserDetail
        user={selectedUser}
        transactions={selectedUserTransactions}
        onBack={() => setSelectedUser(null)}
        onActivate={activateUser}
        onDeactivate={deactivateUser}
        onDelete={deleteUser}
        onDeleteTransactions={deleteUserTransactions}
        onEditBalance={editUserBalance}
      />
    );
  }

  return (
    <div className="pb-24 min-h-screen gradient-hero">
      <div className="max-w-2xl mx-auto px-4 pt-6">
        {/* Header */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl gradient-card-accent flex items-center justify-center">
            <Shield size={20} className="text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">অ্যাডমিন প্যানেল</h1>
            <p className="text-[10px] text-muted-foreground">CashBondhu ম্যানেজমেন্ট</p>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-card rounded-2xl shadow-card p-3.5 text-center">
            <Users size={16} className="text-primary mx-auto mb-1" />
            <p className="text-lg font-bold text-foreground">{users.length}</p>
            <p className="text-[10px] text-muted-foreground">মোট ইউজার</p>
          </div>
          <div className="bg-card rounded-2xl shadow-card p-3.5 text-center">
            <Check size={16} className="text-success mx-auto mb-1" />
            <p className="text-lg font-bold text-foreground">{activeUsers.length}</p>
            <p className="text-[10px] text-muted-foreground">একটিভ</p>
          </div>
          <div className="bg-card rounded-2xl shadow-card p-3.5 text-center">
            <Clock size={16} className="text-amber-500 mx-auto mb-1" />
            <p className="text-lg font-bold text-foreground">{pendingPayments.length}</p>
            <p className="text-[10px] text-muted-foreground">পেন্ডিং পেমেন্ট</p>
          </div>
          <div className="bg-card rounded-2xl shadow-card p-3.5 text-center">
            <CreditCard size={16} className="text-primary mx-auto mb-1" />
            <p className="text-lg font-bold text-foreground">৳{totalRevenue}</p>
            <p className="text-[10px] text-muted-foreground">মোট আয়</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-3">
          <button onClick={() => { setTab("users"); setSearchQuery(""); }} className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all ${tab === "users" ? "gradient-card-accent text-primary-foreground" : "bg-card text-muted-foreground"}`}>
            ব্যবহারকারী ({users.length})
          </button>
          <button onClick={() => { setTab("payments"); setSearchQuery(""); }} className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all relative ${tab === "payments" ? "gradient-card-accent text-primary-foreground" : "bg-card text-muted-foreground"}`}>
            পেমেন্ট ({payments.length})
            {pendingPayments.length > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-destructive text-[10px] text-white flex items-center justify-center font-bold">
                {pendingPayments.length}
              </span>
            )}
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="bg-card rounded-2xl shadow-card p-3 mb-3 space-y-2">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={tab === "users" ? "নাম দিয়ে খুঁজুন..." : "নাম বা TxN ID দিয়ে খুঁজুন..."}
              className="w-full pl-9 pr-3 py-2.5 bg-muted rounded-xl text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30"
            />
          </div>
          <div className="flex gap-2">
            {tab === "users" ? (
              <>
                {["all", "active", "trial", "expired", "none"].map((f) => (
                  <button key={f} onClick={() => setStatusFilter(f)}
                    className={`text-[10px] px-2.5 py-1 rounded-lg font-medium transition-colors ${statusFilter === f ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}>
                    {f === "all" ? "সব" : f === "active" ? "একটিভ" : f === "trial" ? "ট্রায়াল" : f === "expired" ? "মেয়াদোত্তীর্ণ" : "নেই"}
                  </button>
                ))}
              </>
            ) : (
              <>
                {["all", "pending", "approved", "rejected"].map((f) => (
                  <button key={f} onClick={() => setPaymentFilter(f)}
                    className={`text-[10px] px-2.5 py-1 rounded-lg font-medium transition-colors ${paymentFilter === f ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}>
                    {f === "all" ? "সব" : f === "pending" ? "পেন্ডিং" : f === "approved" ? "অনুমোদিত" : "বাতিল"}
                  </button>
                ))}
              </>
            )}
            <button onClick={exportCSV} className="ml-auto text-[10px] px-2.5 py-1 rounded-lg font-medium bg-primary/10 text-primary hover:bg-primary/20 flex items-center gap-1">
              <Download size={12} /> CSV
            </button>
          </div>
        </div>

        {/* Content */}
        {tab === "users" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-2.5">
            {filteredUsers.length === 0 ? (
              <div className="bg-card rounded-2xl shadow-card p-5 text-center">
                <p className="text-sm text-muted-foreground">কোনো ইউজার পাওয়া যায়নি</p>
              </div>
            ) : (
              filteredUsers.map((u) => (
                <AdminUserCard
                  key={u.user_id}
                  user={u}
                  onActivate={activateUser}
                  onDeactivate={deactivateUser}
                  onView={viewUserDetails}
                  onDelete={deleteUser}
                />
              ))
            )}
          </motion.div>
        )}

        {tab === "payments" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-2.5">
            {filteredPayments.length === 0 ? (
              <div className="bg-card rounded-2xl shadow-card p-5 text-center">
                <p className="text-sm text-muted-foreground">কোনো পেমেন্ট রিকোয়েস্ট পাওয়া যায়নি</p>
              </div>
            ) : (
              filteredPayments.map((p) => (
                <AdminPaymentCard
                  key={p.id}
                  payment={p}
                  onApprove={approvePayment}
                  onReject={rejectPayment}
                />
              ))
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;