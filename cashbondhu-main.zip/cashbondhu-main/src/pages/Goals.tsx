import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Target, Plus, Sparkles, TrendingUp, Wallet, Trash2, PiggyBank } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import BackButton from "@/components/BackButton";

const formatBDT = (amount: number) => `৳${amount.toLocaleString("bn-BD")}`;

const goalColors = [
  "from-primary to-accent",
  "from-success to-primary",
  "from-accent to-primary",
];

const Goals = () => {
  const queryClient = useQueryClient();
  const [showGoalForm, setShowGoalForm] = useState(false);
  const [goalTitle, setGoalTitle] = useState("");
  const [goalTarget, setGoalTarget] = useState("");
  const [addAmountId, setAddAmountId] = useState<string | null>(null);
  const [addAmount, setAddAmount] = useState("");
  const [showBudgetForm, setShowBudgetForm] = useState(false);
  const [budgetTitle, setBudgetTitle] = useState("");
  const [budgetLimit, setBudgetLimit] = useState("");

  const { data: goals = [], isLoading: goalsLoading } = useQuery({
    queryKey: ["goals"],
    queryFn: async () => {
      const { data } = await supabase.from("goals").select("*").order("created_at", { ascending: false });
      return data || [];
    },
  });

  const { data: budgets = [], isLoading: budgetsLoading } = useQuery({
    queryKey: ["budgets"],
    queryFn: async () => {
      const { data } = await supabase.from("budgets").select("*").order("created_at", { ascending: false });
      return data || [];
    },
  });

  const loading = goalsLoading || budgetsLoading;

  const addGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    await supabase.from("goals").insert({ title: goalTitle, target_amount: Number(goalTarget) });
    setGoalTitle(""); setGoalTarget(""); setShowGoalForm(false);
    queryClient.invalidateQueries({ queryKey: ["goals"] });
  };

  const deleteGoal = async (id: string) => {
    await supabase.from("goals").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["goals"] });
  };

  const addToGoal = async (goalId: string) => {
    const goal = goals.find((g: any) => g.id === goalId);
    if (!goal || !addAmount) return;
    await supabase.from("goals").update({ current_amount: goal.current_amount + Number(addAmount) }).eq("id", goalId);
    setAddAmountId(null); setAddAmount("");
    queryClient.invalidateQueries({ queryKey: ["goals"] });
  };

  const addBudget = async (e: React.FormEvent) => {
    e.preventDefault();
    await supabase.from("budgets").insert({ title: budgetTitle, budget_limit: Number(budgetLimit) });
    setBudgetTitle(""); setBudgetLimit(""); setShowBudgetForm(false);
    queryClient.invalidateQueries({ queryKey: ["budgets"] });
  };

  const deleteBudget = async (id: string) => {
    await supabase.from("budgets").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["budgets"] });
  };

  return (
    <div className="pb-24 min-h-screen gradient-hero relative">
      <BackButton to="/dashboard" />
      <div className="max-w-lg mx-auto px-4 pt-6">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3 mb-6 pt-8">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-fab">
            <Target size={24} className="text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">লক্ষ্য ও বাজেট</h1>
            <p className="text-xs text-muted-foreground">আপনার আর্থিক স্বপ্ন পূরণ করুন</p>
          </div>
        </motion.div>

        {/* Goals Section */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mb-5">
          <div className="flex justify-between items-center mb-3">
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-primary" />
              <h3 className="text-base font-semibold text-foreground">আমার লক্ষ্য</h3>
            </div>
            <motion.button whileTap={{ scale: 0.85 }} onClick={() => setShowGoalForm(!showGoalForm)} className="p-2 rounded-xl bg-primary/10 hover:bg-primary/20 transition-colors">
              <Plus size={18} className="text-primary" />
            </motion.button>
          </div>

          <AnimatePresence>
            {showGoalForm && (
              <motion.form
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                onSubmit={addGoal}
                className="bg-card rounded-2xl shadow-card p-4 mb-3 space-y-2 overflow-hidden"
              >
                <input value={goalTitle} onChange={e => setGoalTitle(e.target.value)} placeholder="লক্ষ্যের নাম (যেমন: ল্যাপটপ কেনা)" required className="w-full px-3 py-2.5 bg-muted rounded-xl text-foreground placeholder:text-muted-foreground text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                <input value={goalTarget} onChange={e => setGoalTarget(e.target.value)} placeholder="লক্ষ্য পরিমাণ (৳)" type="number" required className="w-full px-3 py-2.5 bg-muted rounded-xl text-foreground placeholder:text-muted-foreground text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                <motion.button whileTap={{ scale: 0.97 }} type="submit" className="w-full py-2.5 rounded-xl gradient-card-accent text-primary-foreground font-semibold text-sm">যোগ করুন</motion.button>
              </motion.form>
            )}
          </AnimatePresence>

          {loading ? (
            <div className="bg-card rounded-2xl shadow-card p-8">
              <p className="text-sm text-muted-foreground text-center">লোড হচ্ছে...</p>
            </div>
          ) : goals.length === 0 ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-card rounded-2xl shadow-card p-8 text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <PiggyBank size={32} className="text-primary" />
              </div>
              <p className="text-sm font-medium text-foreground mb-1">কোনো লক্ষ্য নেই</p>
              <p className="text-xs text-muted-foreground">+ বাটনে ক্লিক করে আপনার প্রথম লক্ষ্য যোগ করুন</p>
            </motion.div>
          ) : (
            <div className="space-y-3">
              {goals.map((goal: any, i: number) => {
                const pct = goal.target_amount > 0 ? Math.min(Math.round((goal.current_amount / goal.target_amount) * 100), 100) : 0;
                const colorClass = goalColors[i % goalColors.length];
                const isComplete = pct >= 100;
                return (
                  <motion.div
                    key={goal.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="bg-card rounded-2xl shadow-card p-4 hover:shadow-card-hover transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${colorClass} flex items-center justify-center flex-shrink-0`}>
                          {isComplete ? (
                            <span className="text-lg">🎉</span>
                          ) : (
                            <TrendingUp size={18} className="text-primary-foreground" />
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-foreground">{goal.title}</p>
                          <p className="text-xs text-muted-foreground">{formatBDT(goal.current_amount)} / {formatBDT(goal.target_amount)}</p>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <button onClick={(e) => { e.stopPropagation(); setAddAmountId(addAmountId === goal.id ? null : goal.id); }} className="p-1.5 rounded-lg hover:bg-primary/10 transition-colors active:scale-90">
                          <Plus size={14} className="text-primary" />
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); deleteGoal(goal.id); }} className="p-1.5 rounded-lg hover:bg-destructive/10 transition-colors active:scale-90">
                          <Trash2 size={14} className="text-destructive" />
                        </button>
                      </div>
                    </div>

                    {/* Progress */}
                    <div className="relative h-3 bg-muted rounded-full overflow-hidden mb-1">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ duration: 1, delay: 0.2 }}
                        className={`h-full rounded-full bg-gradient-to-r ${colorClass}`}
                      />
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[10px] text-muted-foreground">{pct}% সম্পন্ন</span>
                      <span className="text-[10px] text-muted-foreground">{formatBDT(Math.max(goal.target_amount - goal.current_amount, 0))} বাকি</span>
                    </div>

                    {/* Add amount inline */}
                    <AnimatePresence>
                      {addAmountId === goal.id && (
                        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="flex gap-2 mt-3 overflow-hidden">
                          <input value={addAmount} onChange={e => setAddAmount(e.target.value)} placeholder="টাকার পরিমাণ" type="number" className="flex-1 px-3 py-2 bg-muted rounded-xl text-foreground placeholder:text-muted-foreground text-xs outline-none focus:ring-2 focus:ring-primary/30" />
                          <button type="button" onClick={(e) => { e.stopPropagation(); addToGoal(goal.id); }} className="px-4 py-2 rounded-xl gradient-card-accent text-primary-foreground text-xs font-semibold active:scale-95 transition-transform">যোগ</button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                );
              })}
            </div>
          )}
        </motion.div>

        {/* Budget Section */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
          <div className="flex justify-between items-center mb-3">
            <div className="flex items-center gap-2">
              <Wallet size={16} className="text-primary" />
              <h3 className="text-base font-semibold text-foreground">বাজেট ট্র্যাকার</h3>
            </div>
            <motion.button whileTap={{ scale: 0.85 }} onClick={() => setShowBudgetForm(!showBudgetForm)} className="p-2 rounded-xl bg-primary/10 hover:bg-primary/20 transition-colors">
              <Plus size={18} className="text-primary" />
            </motion.button>
          </div>

          <AnimatePresence>
            {showBudgetForm && (
              <motion.form
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                onSubmit={addBudget}
                className="bg-card rounded-2xl shadow-card p-4 mb-3 space-y-2 overflow-hidden"
              >
                <input value={budgetTitle} onChange={e => setBudgetTitle(e.target.value)} placeholder="বাজেটের নাম" required className="w-full px-3 py-2.5 bg-muted rounded-xl text-foreground placeholder:text-muted-foreground text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                <input value={budgetLimit} onChange={e => setBudgetLimit(e.target.value)} placeholder="সীমা (৳)" type="number" required className="w-full px-3 py-2.5 bg-muted rounded-xl text-foreground placeholder:text-muted-foreground text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                <motion.button whileTap={{ scale: 0.97 }} type="submit" className="w-full py-2.5 rounded-xl gradient-card-accent text-primary-foreground font-semibold text-sm">যোগ করুন</motion.button>
              </motion.form>
            )}
          </AnimatePresence>

          {loading ? (
            <div className="bg-card rounded-2xl shadow-card p-8">
              <p className="text-sm text-muted-foreground text-center">লোড হচ্ছে...</p>
            </div>
          ) : budgets.length === 0 ? (
            <div className="bg-card rounded-2xl shadow-card p-8 text-center">
              <p className="text-sm text-muted-foreground">কোনো বাজেট নেই। + বাটনে ক্লিক করে যোগ করুন।</p>
            </div>
          ) : (
            <div className="space-y-3">
              {budgets.map((b: any) => {
                const pct = b.budget_limit > 0 ? Math.round((b.spent / b.budget_limit) * 100) : 0;
                const left = b.budget_limit - b.spent;
                const isOver = pct > 80;
                return (
                  <motion.div key={b.id} whileTap={{ scale: 0.98 }} className="bg-card rounded-2xl shadow-card p-4 flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${isOver ? "bg-destructive/15" : "bg-secondary"}`}>
                      <Wallet size={18} className={isOver ? "text-destructive" : "text-primary"} />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between text-sm mb-1">
                        <span className="font-medium text-foreground">{b.title}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-muted-foreground text-xs">{formatBDT(Math.max(left, 0))} বাকি</span>
                          <button onClick={(e) => { e.stopPropagation(); deleteBudget(b.id); }} className="p-1 rounded hover:bg-destructive/10 transition-colors active:scale-90">
                            <Trash2 size={12} className="text-destructive" />
                          </button>
                        </div>
                      </div>
                      <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                        <motion.div initial={{ width: 0 }} animate={{ width: `${Math.min(pct, 100)}%` }} transition={{ duration: 0.8, delay: 0.3 }} className={`h-full rounded-full ${isOver ? "bg-destructive" : "gradient-card-accent"}`} />
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Goals;
