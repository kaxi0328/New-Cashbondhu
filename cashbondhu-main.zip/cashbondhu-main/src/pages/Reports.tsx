import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { bn } from "date-fns/locale";
import { CalendarIcon, Search, X, Settings2 } from "lucide-react";
import GaugeChart from "@/components/GaugeChart";
import BackButton from "@/components/BackButton";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

const formatBDT = (amount: number) => `৳${Math.abs(amount).toLocaleString("bn-BD")}`;

const LIMIT_KEY = "cashbondhu_expense_limit";

const Reports = () => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [searchQuery, setSearchQuery] = useState("");
  const [expenseLimit, setExpenseLimit] = useState<number>(() => {
    const saved = localStorage.getItem(LIMIT_KEY);
    return saved ? Number(saved) : 10000;
  });
  const [editingLimit, setEditingLimit] = useState(false);
  const [limitInput, setLimitInput] = useState(String(expenseLimit));

  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ["transactions", "all"],
    queryFn: async () => {
      const { data } = await supabase.from("transactions").select("*").order("created_at", { ascending: false });
      return data || [];
    },
  });

  const filteredTransactions = useMemo(() => {
    let filtered = transactions;

    if (selectedDate) {
      const dateStr = format(selectedDate, "yyyy-MM-dd");
      filtered = filtered.filter((tx: any) => tx.created_at?.startsWith(dateStr));
    }

    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      filtered = filtered.filter((tx: any) =>
        tx.title?.toLowerCase().includes(q) ||
        tx.category?.toLowerCase().includes(q) ||
        tx.description?.toLowerCase().includes(q)
      );
    }

    return filtered;
  }, [transactions, selectedDate, searchQuery]);

  const groupedByDate = useMemo(() => {
    const groups: Record<string, { transactions: any[]; income: number; expense: number }> = {};
    filteredTransactions.forEach((tx: any) => {
      const dateKey = tx.created_at?.split("T")[0] || "unknown";
      if (!groups[dateKey]) groups[dateKey] = { transactions: [], income: 0, expense: 0 };
      groups[dateKey].transactions.push(tx);
      if (tx.type === "income") groups[dateKey].income += Number(tx.amount);
      else groups[dateKey].expense += Math.abs(Number(tx.amount));
    });
    return Object.entries(groups).sort(([a], [b]) => b.localeCompare(a));
  }, [filteredTransactions]);

  const totalExpense = filteredTransactions.filter((t: any) => t.type === "expense").reduce((s: number, t: any) => s + Math.abs(Number(t.amount)), 0);

  const formatDateLabel = (dateStr: string) => {
    try {
      const d = new Date(dateStr + "T00:00:00");
      const today = new Date();
      const yesterday = new Date();
      yesterday.setDate(today.getDate() - 1);

      if (format(d, "yyyy-MM-dd") === format(today, "yyyy-MM-dd")) return "আজ";
      if (format(d, "yyyy-MM-dd") === format(yesterday, "yyyy-MM-dd")) return "গতকাল";
      return format(d, "dd MMMM, yyyy", { locale: bn });
    } catch {
      return dateStr;
    }
  };

  const clearFilters = () => {
    setSelectedDate(undefined);
    setSearchQuery("");
  };

  const hasFilters = !!selectedDate || !!searchQuery.trim();

  const saveLimit = () => {
    const val = Math.max(Number(limitInput) || 1000, 100);
    setExpenseLimit(val);
    localStorage.setItem(LIMIT_KEY, String(val));
    setEditingLimit(false);
  };

  return (
    <div className="pb-24 min-h-screen gradient-hero relative">
      <BackButton to="/dashboard" />
      <div className="max-w-lg mx-auto px-4 pt-6">
        <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-2xl font-bold text-foreground mb-4">
          আর্থিক রিপোর্ট
        </motion.h1>

        {/* Search & Calendar Filter */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="flex gap-2 mb-4">
          <div className="flex-1 relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="লেনদেন খুঁজুন..."
              className="w-full pl-9 pr-3 py-2.5 bg-card rounded-xl text-foreground placeholder:text-muted-foreground text-sm outline-none focus:ring-2 focus:ring-primary/30 shadow-card"
            />
          </div>
          <Popover>
            <PopoverTrigger asChild>
              <button
                className={cn(
                  "flex items-center gap-1.5 px-3 py-2.5 rounded-xl text-sm font-medium shadow-card transition-colors",
                  selectedDate ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:text-foreground"
                )}
              >
                <CalendarIcon size={16} />
                {selectedDate ? format(selectedDate, "dd/MM") : "তারিখ"}
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                initialFocus
                className={cn("p-3 pointer-events-auto")}
              />
            </PopoverContent>
          </Popover>
        </motion.div>

        {hasFilters && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mb-4">
            <button onClick={clearFilters} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-destructive/10 text-destructive text-xs font-medium">
              <X size={14} /> ফিল্টার মুছুন
            </button>
          </motion.div>
        )}

        {/* Gauge with editable limit */}
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }} className="bg-card rounded-2xl shadow-card p-5 mb-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-muted-foreground">
              {hasFilters ? "ফিল্টারকৃত খরচ" : "মোট খরচ"}
            </h3>
            <button
              onClick={() => { setEditingLimit(true); setLimitInput(String(expenseLimit)); }}
              className="flex items-center gap-1 text-xs text-primary font-medium hover:underline"
            >
              <Settings2 size={14} /> সীমা সেট
            </button>
          </div>

          {editingLimit && (
            <div className="flex gap-2 mb-4">
              <input
                type="number"
                value={limitInput}
                onChange={(e) => setLimitInput(e.target.value)}
                className="flex-1 px-3 py-2 bg-secondary rounded-xl text-foreground text-sm outline-none focus:ring-2 focus:ring-primary/30"
                placeholder="খরচের সীমা লিখুন..."
                autoFocus
              />
              <button onClick={saveLimit} className="px-4 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-xl">
                সেভ
              </button>
              <button onClick={() => setEditingLimit(false)} className="px-3 py-2 bg-secondary text-muted-foreground text-sm rounded-xl">
                ✕
              </button>
            </div>
          )}

          <GaugeChart spent={totalExpense} limit={expenseLimit} />
        </motion.div>

        {/* Transactions grouped by date */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          {isLoading ? (
            <p className="text-sm text-muted-foreground text-center py-4">লোড হচ্ছে...</p>
          ) : groupedByDate.length === 0 ? (
            <div className="bg-card rounded-2xl shadow-card p-5">
              <p className="text-sm text-muted-foreground text-center py-4">
                {hasFilters ? "এই ফিল্টারে কোনো লেনদেন পাওয়া যায়নি।" : "কোনো লেনদেন নেই।"}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {groupedByDate.map(([dateKey, group]) => (
                <div key={dateKey} className="bg-card rounded-2xl shadow-card overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3 border-b border-border/50">
                    <span className="text-sm font-semibold text-foreground">{formatDateLabel(dateKey)}</span>
                    <div className="flex gap-3 text-xs font-medium">
                      {group.income > 0 && <span className="text-success">+{formatBDT(group.income)}</span>}
                      {group.expense > 0 && <span className="text-destructive">-{formatBDT(group.expense)}</span>}
                    </div>
                  </div>
                  <div className="divide-y divide-border/30">
                    {group.transactions.map((tx: any) => {
                      const isIncome = tx.type === "income";
                      return (
                        <div key={tx.id} className="flex items-center gap-3 px-4 py-3">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold flex-shrink-0 ${isIncome ? "bg-success/15 text-success" : "bg-destructive/10 text-destructive"}`}>
                            {isIncome ? "+" : "−"}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-foreground truncate">{tx.title}</p>
                            <p className="text-xs text-muted-foreground">{tx.category}</p>
                          </div>
                          <span className={`text-sm font-semibold ${isIncome ? "text-success" : "text-foreground"}`}>
                            {isIncome ? "+" : "-"}{formatBDT(tx.amount)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Reports;
