import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Wallet, BarChart3, Target, StickyNote, Shield, ArrowRight, GraduationCap, MapPin, Phone, User } from "lucide-react";
import ThemeToggle from "@/components/ThemeToggle";

const features = [
  { icon: Wallet, title: "স্মার্ট বাজেটিং", desc: "সুন্দর ক্যাটাগরি ব্রেকডাউন এবং ডোনাট চার্টের মাধ্যমে প্রতিটি টাকার হিসাব রাখুন।" },
  { icon: BarChart3, title: "আর্থিক রিপোর্ট", desc: "সাপ্তাহিক, মাসিক, ত্রৈমাসিক বিশ্লেষণ গেজ চার্ট এবং লেনদেনের ইতিহাস সহ।" },
  { icon: Target, title: "লক্ষ্য ট্র্যাকিং", desc: "সঞ্চয় লক্ষ্য এবং বাজেট সীমা নির্ধারণ করুন ভিজ্যুয়াল প্রগ্রেস বার সহ।" },
  { icon: StickyNote, title: "কাজের নোট", desc: "আপনার প্রোডাক্টিভিটি নোটগুলো একটি পরিষ্কার লেআউটে সাজিয়ে রাখুন।" },
  { icon: Shield, title: "নিরাপদ ও গোপনীয়", desc: "আপনার ডেটা এন্টারপ্রাইজ-গ্রেড অথেনটিকেশন দিয়ে সুরক্ষিত।" },
];

const creatorInfo = [
  { icon: User, label: "নাম", value: "Kazi Robiul (KR)" },
  { icon: GraduationCap, label: "কলেজ", value: "Narsingdi Science College" },
  { icon: BarChart3, label: "গ্রুপ", value: "Science" },
  { icon: MapPin, label: "অবস্থান", value: "Narsingdi, Bangladesh" },
  { icon: Phone, label: "WhatsApp", value: "01862713595" },
];

const Landing = () => {
  return (
    <div className="min-h-screen gradient-hero">
      {/* হেডার */}
      <header className="flex items-center justify-between px-5 py-4 max-w-5xl mx-auto">
        <h2 className="text-xl font-bold text-primary">CashBondhu</h2>
        <div className="flex gap-2 items-center">
          <ThemeToggle />
          <Link to="/login" className="px-4 py-2 text-sm font-medium text-primary hover:bg-secondary rounded-xl transition-colors">
            লগইন
          </Link>
          <Link to="/signup" className="px-4 py-2 text-sm font-medium gradient-card-accent text-primary-foreground rounded-xl hover:opacity-90 transition-opacity">
            সাইন আপ
          </Link>
        </div>
      </header>

      {/* হিরো */}
      <section className="px-5 pt-12 pb-16 max-w-5xl mx-auto text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <span className="inline-block px-4 py-1.5 bg-secondary text-secondary-foreground text-xs font-semibold rounded-full mb-5">
            ✨ আপনার ব্যক্তিগত অর্থ সঙ্গী
          </span>
          <h1 className="text-4xl md:text-5xl font-bold text-foreground leading-tight mb-4">
            আপনার আর্থিক ভবিষ্যতের <br />
            <span className="text-primary">নিয়ন্ত্রণ নিন</span>
          </h1>
          <p className="text-muted-foreground text-base md:text-lg max-w-md mx-auto mb-8">
            খরচ ট্র্যাক করুন, লক্ষ্য নির্ধারণ করুন, এবং প্রোডাক্টিভ থাকুন — সবকিছু একটি সুন্দর অ্যাপে।
          </p>
          <Link
            to="/signup"
            className="inline-flex items-center gap-2 px-6 py-3 gradient-card-accent text-primary-foreground font-semibold rounded-xl shadow-fab hover:opacity-90 transition-opacity"
          >
            বিনামূল্যে শুরু করুন <ArrowRight size={18} />
          </Link>
        </motion.div>
      </section>

      {/* ফিচার */}
      <section className="px-5 pb-16 max-w-5xl mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + i * 0.1 }}
              className="bg-card rounded-2xl shadow-card p-6 hover:shadow-card-hover transition-shadow"
            >
              <div className="w-11 h-11 rounded-xl bg-secondary flex items-center justify-center mb-4">
                <f.icon size={22} className="text-primary" />
              </div>
              <h3 className="text-base font-semibold text-foreground mb-1.5">{f.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ক্রিয়েটর সেকশন */}
      <section className="px-5 pb-20 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="bg-card rounded-2xl shadow-card overflow-hidden"
        >
          <div className="gradient-card-accent px-6 py-8 text-center">
            <div className="w-20 h-20 rounded-full bg-primary-foreground/20 backdrop-blur-sm flex items-center justify-center mx-auto mb-4 border-2 border-primary-foreground/30">
              <span className="text-3xl font-bold text-primary-foreground">KR</span>
            </div>
            <h2 className="text-2xl font-bold text-primary-foreground mb-1">Kazi Robiul</h2>
            <p className="text-primary-foreground/80 text-sm">ডেভেলপার ও ক্রিয়েটর — CashBondhu</p>
          </div>

          <div className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4 text-center">ক্রিয়েটর সম্পর্কে</h3>
            <p className="text-sm text-muted-foreground text-center mb-6 leading-relaxed max-w-md mx-auto">
              CashBondhu তৈরি করেছেন Kazi Robiul (KR) — একজন তরুণ ডেভেলপার যিনি মানুষের দৈনন্দিন আর্থিক হিসাব সহজ করতে এই অ্যাপটি ডিজাইন করেছেন।
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg mx-auto">
              {creatorInfo.map((item, i) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.8 + i * 0.1 }}
                  className="flex items-center gap-3 bg-secondary/50 rounded-xl px-4 py-3"
                >
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <item.icon size={16} className="text-primary" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[11px] text-muted-foreground">{item.label}</p>
                    <p className="text-sm font-medium text-foreground truncate">{item.value}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </section>

      {/* ফুটার */}
      <footer className="px-5 py-8 border-t border-border text-center space-y-1">
        <p className="text-xs text-muted-foreground">© ২০২৬ CashBondhu। সর্বস্বত্ব সংরক্ষিত।</p>
        <p className="text-xs text-muted-foreground">Created by KR (Kazi Robiul)</p>
      </footer>
    </div>
  );
};

export default Landing;
