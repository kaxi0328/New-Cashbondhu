import { motion } from "framer-motion";
import { LogOut, Shield, UserCircle, TrendingUp, TrendingDown, Zap, Home as HomeIcon, ShoppingBag, Briefcase } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import ThemeToggle from "@/components/ThemeToggle";
import IslamicToggle from "@/components/IslamicToggle";
import { useIslamicMode } from "@/contexts/IslamicModeContext";
import SalamPopup from "@/components/islamic/SalamPopup";
import HadithBox from "@/components/islamic/HadithBox";
import PrayerTimes from "@/components/islamic/PrayerTimes";
import PrayerVote from "@/components/islamic/PrayerVote";
import SubscriptionWarning from "@/components/SubscriptionWarning";
import SubscriptionBanner from "@/components/SubscriptionBanner";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, CartesianGrid, Tooltip } from "recharts";

const formatBDT = (amount: number) => `৳${Math.abs(amount).toLocaleString("bn-BD")}`;

const categoryIcons: Record<string, any> = {
  "ফ্রিল্যান্স": Zap, "বেতন": Briefcase, "ভাড়া": HomeIcon, "ইউটিলিটি": Zap, "খাবার": ShoppingBag,
};

const Dashboard = () => {
  const { user, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();
  const name = user?.user_metadata?.full_name || "বন্ধু";
  const { islamicMode } = useIslamicMode();

  const { data: profileData } = useQuery({
    queryKey: ["profile", user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data } = await supabase.from("profiles").select("full_name").eq("user_id", user.id).single();
      return data;
    },
    enabled: !!user,
  });

  const displayName = profileData?.full_name || name;

  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ["transactions", "recent"],
    queryFn: async () => {
      const { data } = await supabase.from("transactions").select("*").order("created_at", { ascending: false }).limit(5);
      return data || [];
    },
  });

  const { data: totals } = useQuery({
    queryKey: ["transactions", "totals"],
    queryFn: async () => {
      const { data } = await supabase.from("transactions").select("amount, type");
      const income = (data || []).filter(t => t.type === "income").reduce((s, t) => s + Number(t.amount), 0);
      const expense = (data || []).filter(t => t.type === "expense").reduce((s, t) => s + Math.abs(Number(t.amount)), 0);
      return { income, expense };
    },
  });

  const totalIncome = totals?.income || 0;
  const totalExpense = totals?.expense || 0;
  const balance = totalIncome - totalExpense;

  const barData = [
    { name: "আয়", value: totalIncome, fill: "hsl(152, 55%, 48%)" },
    { name: "ব্যয়", value: totalExpense, fill: "hsl(0, 72%, 55%)" },
  ];

  const handleLogout = async () => { await signOut(); navigate("/"); };

  return (
    <div className="pb-24 min-h-screen gradient-hero">
      <div className="max-w-lg mx-auto px-4 pt-6">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-6 flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-foreground">হাই! কেমন আছেন? 👋</h1>
            <p className="text-muted-foreground text-sm">আপনার অর্থায়নে স্বাগতম, {displayName}</p>
          </div>
          <div className="flex gap-2">
            <IslamicToggle />
            <ThemeToggle />
            <motion.button whileTap={{ scale: 0.85 }} onClick={() => navigate("/profile")} className="p-2 rounded-xl bg-card shadow-card hover:shadow-card-hover transition-shadow">
              <UserCircle size={20} className="text-primary" />
            </motion.button>
            {isAdmin && (
              <motion.button whileTap={{ scale: 0.85 }} onClick={() => navigate("/admin")} className="p-2 rounded-xl bg-card shadow-card hover:shadow-card-hover transition-shadow">
                <Shield size={20} className="text-primary" />
              </motion.button>
            )}
            <motion.button whileTap={{ scale: 0.85 }} onClick={handleLogout} className="p-2 rounded-xl bg-card shadow-card hover:shadow-card-hover transition-shadow">
              <LogOut size={20} className="text-muted-foreground" />
            </motion.button>
          </div>
        </motion.div>

        {/* Main Balance */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="rounded-2xl p-5 gradient-card-accent text-primary-foreground relative overflow-hidden mb-5">
          <div className="absolute top-3 right-3 w-10 h-6 rounded-md bg-primary-foreground/20" />
          <p className="text-xs font-medium mb-1 opacity-80">মোট ব্যালেন্স</p>
          <p className="text-3xl font-bold mt-2">৳{balance.toLocaleString("bn-BD")}</p>
        </motion.div>

        {/* Subscription Warnings */}
        <SubscriptionBanner />
        <SubscriptionWarning />

        {/* Islamic Widgets */}
        {islamicMode && (
          <>
            <SalamPopup name={displayName} />
            <HadithBox />
            <PrayerTimes />
            <PrayerVote />
          </>
        )}

        {/* Income / Expense Summary */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="bg-card rounded-2xl shadow-card p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-success/15 flex items-center justify-center">
                <TrendingUp size={16} className="text-success" />
              </div>
              <span className="text-xs font-medium text-success">মোট আয়</span>
            </div>
            <p className="text-xl font-bold text-foreground">৳{totalIncome.toLocaleString("bn-BD")}</p>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-card rounded-2xl shadow-card p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-destructive/15 flex items-center justify-center">
                <TrendingDown size={16} className="text-destructive" />
              </div>
              <span className="text-xs font-medium text-destructive">মোট ব্যয়</span>
            </div>
            <p className="text-xl font-bold text-foreground">৳{totalExpense.toLocaleString("bn-BD")}</p>
          </motion.div>
        </div>

        {/* Bar Chart */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }} className="bg-card rounded-2xl shadow-card p-5 mb-5">
          <h3 className="text-base font-semibold text-foreground mb-4">আয় বনাম ব্যয়</h3>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData} barCategoryGap="40%">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="name" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `৳${v}`} />
                <Tooltip formatter={(value: number) => [`৳${value.toLocaleString("bn-BD")}`, ""]} contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12, fontSize: 12 }} labelStyle={{ color: "hsl(var(--foreground))" }} />
                <Bar dataKey="value" radius={[8, 8, 0, 0]} barSize={50} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Recent Activity */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-base font-semibold text-foreground">সাম্প্রতিক কার্যক্রম</h3>
            <button onClick={() => navigate("/reports")} className="text-xs text-primary font-medium">সব দেখুন</button>
          </div>
          {isLoading ? (
            <p className="text-sm text-muted-foreground text-center py-4">লোড হচ্ছে...</p>
          ) : transactions.length === 0 ? (
            <div className="bg-card rounded-2xl shadow-card p-5">
              <p className="text-sm text-muted-foreground text-center py-4">কোনো লেনদেন নেই। নিচের + বাটনে ক্লিক করে যোগ করুন।</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {transactions.map((tx: any) => {
                const isPositive = tx.type === "income";
                const IconComp = categoryIcons[tx.category] || Zap;
                const dateStr = new Date(tx.created_at).toISOString().split("T")[0];
                return (
                  <motion.div key={tx.id} whileTap={{ scale: 0.98 }} className="flex items-center gap-3 bg-card rounded-2xl shadow-card p-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${isPositive ? "bg-success/15" : "bg-destructive/10"}`}>
                      <IconComp size={18} className={isPositive ? "text-success" : "text-destructive"} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{tx.title}</p>
                      <p className="text-xs text-muted-foreground">{tx.category} • {dateStr}</p>
                    </div>
                    <span className={`text-sm font-semibold ${isPositive ? "text-success" : "text-destructive"}`}>
                      {isPositive ? "+" : "-"}{formatBDT(tx.amount)}
                    </span>
                  </motion.div>
                );
              })}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;
