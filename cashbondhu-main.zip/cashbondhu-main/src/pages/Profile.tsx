import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Camera, ArrowLeft, Save, CreditCard } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import ThemeToggle from "@/components/ThemeToggle";
import { useTheme } from "next-themes";
import { useSubscription } from "@/contexts/SubscriptionContext";
import PaymentModal from "@/components/PaymentModal";

const Profile = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [fullName, setFullName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [paymentOpen, setPaymentOpen] = useState(false);
  const { status, daysLeft, expiresAt } = useSubscription();

  useEffect(() => {
    if (!user) return;
    const fetchProfile = async () => {
      const { data } = await supabase
        .from("profiles")
        .select("full_name, avatar_url")
        .eq("user_id", user.id)
        .single();
      if (data) {
        setFullName(data.full_name || "");
        setAvatarUrl(data.avatar_url);
      }
    };
    fetchProfile();
  }, [user]);

  const uploadAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setUploading(true);

    const ext = file.name.split(".").pop();
    const path = `${user.id}/avatar.${ext}`;

    const { error } = await supabase.storage.from("avatars").upload(path, file, { upsert: true });
    if (error) {
      toast({ title: "ত্রুটি", description: "ছবি আপলোড করা যায়নি।", variant: "destructive" });
      setUploading(false);
      return;
    }

    const { data: urlData } = supabase.storage.from("avatars").getPublicUrl(path);
    const url = urlData.publicUrl + "?t=" + Date.now();

    await supabase.from("profiles").update({ avatar_url: url }).eq("user_id", user.id);
    setAvatarUrl(url);
    setUploading(false);
    toast({ title: "সফল!", description: "প্রোফাইল ছবি আপডেট হয়েছে।" });
  };

  const saveProfile = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({ full_name: fullName })
      .eq("user_id", user.id);
    setSaving(false);
    if (error) {
      toast({ title: "ত্রুটি", description: "নাম সংরক্ষণ করা যায়নি।", variant: "destructive" });
    } else {
      toast({ title: "সফল!", description: "প্রোফাইল আপডেট হয়েছে।" });
    }
  };

  const initials = fullName ? fullName.charAt(0).toUpperCase() : "?";

  return (
    <div className="pb-24 min-h-screen gradient-hero">
      <div className="max-w-lg mx-auto px-4 pt-6">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center justify-between mb-8">
          <button onClick={() => navigate(-1)} className="p-2 rounded-xl bg-card shadow-card hover:shadow-card-hover transition-shadow">
            <ArrowLeft size={20} className="text-foreground" />
          </button>
          <h1 className="text-xl font-bold text-foreground">প্রোফাইল</h1>
          <ThemeToggle />
        </motion.div>

        {/* Avatar */}
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }} className="flex flex-col items-center mb-8">
          <div className="relative">
            <div className="w-28 h-28 rounded-full overflow-hidden bg-secondary flex items-center justify-center shadow-card-hover border-4 border-primary/20">
              {avatarUrl ? (
                <img src={avatarUrl} alt="অ্যাভাটার" className="w-full h-full object-cover" />
              ) : (
                <span className="text-4xl font-bold text-primary">{initials}</span>
              )}
            </div>
            <label className="absolute bottom-0 right-0 w-9 h-9 rounded-full gradient-card-accent flex items-center justify-center cursor-pointer shadow-fab">
              {uploading ? (
                <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
              ) : (
                <Camera size={16} className="text-primary-foreground" />
              )}
              <input type="file" accept="image/*" onChange={uploadAvatar} className="hidden" />
            </label>
          </div>
          <p className="mt-3 text-sm text-muted-foreground">{user?.email}</p>
        </motion.div>

        {/* Form */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-card rounded-2xl shadow-card p-5 space-y-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">পুরো নাম</label>
            <input
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="আপনার নাম লিখুন"
              className="w-full px-4 py-3 bg-muted rounded-xl text-foreground placeholder:text-muted-foreground text-sm outline-none focus:ring-2 focus:ring-primary/30"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">ইমেইল</label>
            <input
              value={user?.email || ""}
              disabled
              className="w-full px-4 py-3 bg-muted rounded-xl text-muted-foreground text-sm outline-none opacity-60"
            />
          </div>

          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={saveProfile}
            disabled={saving}
            className="w-full py-3 rounded-xl gradient-card-accent text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <Save size={16} />
            {saving ? "সংরক্ষণ হচ্ছে..." : "সংরক্ষণ করুন"}
          </motion.button>
        </motion.div>

        {/* থিম সেকশন */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-card rounded-2xl shadow-card p-5 mt-4">
          <h3 className="text-base font-semibold text-foreground mb-3">থিম</h3>
          <p className="text-sm text-muted-foreground mb-3">আপনার পছন্দের থিম নির্বাচন করুন</p>
          <div className="flex gap-3">
            <ThemeButton mode="light" label="লাইট" />
            <ThemeButton mode="dark" label="ডার্ক" />
          </div>
        </motion.div>

        {/* সাবস্ক্রিপশন সেকশন */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="bg-card rounded-2xl shadow-card p-5 mt-4">
          <div className="flex items-center gap-2 mb-3">
            <CreditCard size={18} className="text-primary" />
            <h3 className="text-base font-semibold text-foreground">সাবস্ক্রিপশন</h3>
          </div>
          <div className="bg-muted rounded-xl p-3 mb-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-muted-foreground">স্ট্যাটাস</span>
              <span className={`text-xs px-2 py-0.5 rounded-lg font-medium ${
                status === "active" ? "bg-success/10 text-success" :
                status === "trial" ? "bg-blue-500/10 text-blue-500" :
                "bg-destructive/10 text-destructive"
              }`}>
                {status === "active" ? "একটিভ" : status === "trial" ? "ফ্রি ট্রায়াল" : "মেয়াদোত্তীর্ণ"}
              </span>
            </div>
            {expiresAt && (
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">মেয়াদ শেষ</span>
                <span className="text-xs font-medium text-foreground">{new Date(expiresAt).toLocaleDateString("bn-BD")} ({daysLeft} দিন বাকি)</span>
              </div>
            )}
          </div>
          <p className="text-xs text-muted-foreground mb-3">মাসিক সাবস্ক্রিপশন ফি মাত্র ৳২০। বিকাশ, নগদ বা উপায়ে পেমেন্ট করুন।</p>
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => setPaymentOpen(true)}
            className="w-full py-2.5 rounded-xl gradient-card-accent text-primary-foreground font-semibold text-sm"
          >
            পেমেন্ট করুন
          </motion.button>
        </motion.div>

        <PaymentModal open={paymentOpen} onClose={() => setPaymentOpen(false)} />
      </div>
    </div>
  );
};

const ThemeButton = ({ mode, label }: { mode: string; label: string }) => {
  const { theme, setTheme } = useTheme();
  const active = theme === mode;

  return (
    <motion.button
      whileTap={{ scale: 0.95 }}
      onClick={() => setTheme(mode)}
      className={`flex-1 py-3 rounded-xl text-sm font-medium transition-all border-2 ${
        active
          ? "border-primary bg-primary/10 text-primary"
          : "border-border bg-muted text-muted-foreground hover:border-primary/30"
      }`}
    >
      {label}
    </motion.button>
  );
};

export default Profile;
